# Zarnly

Production foundation. Next.js 15 (App Router) + TypeScript + Tailwind + shadcn/ui, on Supabase (Postgres, Auth, Storage) with Resend for transactional email, deployed on Vercel.

This repository currently contains **only the foundation** — auth wiring, route protection, error handling, theming, and code-quality tooling. No product features are implemented yet.

## Stack

| Layer | Choice |
|---|---|
| Framework | Next.js 15, App Router, React 19, TypeScript (strict) |
| Styling | Tailwind CSS + shadcn/ui (Radix primitives), CSS-variable theming |
| Database / Auth / Storage | Supabase (Postgres + Row Level Security) |
| Email | Resend |
| Hosting | Vercel |
| Testing | Vitest + Testing Library |

## Getting started

```bash
npm install
cp .env.example .env.local   # fill in real values — see comments in the file
npm run dev
```

Visit `http://localhost:3000`. The root page renders a foundation status view (session state, theme toggle) rather than a marketing page — it exists to prove the wiring works end-to-end.

### Supabase

```bash
npx supabase start        # local Postgres + Auth + Storage via Docker
npx supabase db reset      # applies supabase/migrations/*
npm run db:types           # regenerates src/types/database.types.ts
```

Point `.env.local` at either the local stack (`supabase status` prints the URL/keys) or a hosted Supabase project.

## Folder structure

```
src/
├── app/                      # Routes (App Router). File-based, thin.
│   ├── (auth)/                # Route group: sign-in, sign-up — chrome-free layout
│   ├── (protected)/            # Route group: authenticated app shell
│   ├── api/                   # Route handlers (health check, future webhooks)
│   ├── auth/callback/          # OAuth / magic-link code exchange
│   ├── layout.tsx              # Root layout: fonts, metadata, providers
│   ├── page.tsx                 # Foundation status page
│   ├── error.tsx                # Segment-level error boundary
│   ├── global-error.tsx          # Root-layout-failure boundary
│   ├── not-found.tsx              # 404
│   └── loading.tsx                 # Default route-level loading state
│
├── components/
│   ├── ui/                    # shadcn/ui primitives (button, card, toast, …)
│   ├── layout/                 # App chrome: header, container, theme toggle
│   ├── providers/                # Client provider composition (theme, toasts, tooltips)
│   └── shared/                    # Cross-feature building blocks (spinner, skeleton)
│
├── lib/
│   ├── supabase/                # client.ts / server.ts / admin.ts / middleware.ts
│   ├── auth/                     # Session helpers + auth server actions
│   ├── resend/                    # Transactional email wrapper
│   ├── errors/                     # AppError hierarchy + logger
│   ├── env.ts                       # Validated, typed environment access
│   └── utils.ts                      # cn() and other framework-agnostic helpers
│
├── hooks/                     # use-auth, use-toast, use-media-query
├── types/                     # auth.types, api.types, database.types (generated)
├── config/                    # site.ts, routes.ts — single source of truth for constants
└── middleware.ts               # Route protection (auth-gates protected route groups)

supabase/
└── migrations/                 # SQL migrations, applied via Supabase CLI
```

### Why this shape

**`app/` stays thin.** Route files handle data-fetching orchestration and composition; they import from `lib/` and `components/` rather than containing business logic inline. This keeps routes easy to scan and keeps logic testable outside of Next.js's rendering lifecycle.

**Three Supabase clients, not one.** `lib/supabase/client.ts` (browser), `server.ts` (Server Components / Actions / Route Handlers), and `admin.ts` (service role, bypasses RLS) are separate files with separate import boundaries. Mixing these up is the single most common way Supabase apps leak data — keeping them physically separate makes the mistake harder to make and easy to grep for in review.

**Auth has no UI yet, on purpose.** `lib/auth/session.ts` and `middleware.ts` fully implement session resolution and route protection. Sign-in/sign-up pages are structural placeholders — the actual form UI depends on a product decision (password vs. magic link vs. OAuth) that belongs to a feature slice, not the foundation.

**Route protection is opt-in, not opt-out.** `config/routes.ts` defines `protectedRoutePrefixes` as an explicit allowlist. A new route is public by default; it only requires auth once its prefix is added there. This fails safe in the direction that matters less (an accidentally-public route is a bug you'll notice; an accidentally-protected one silently locks users out).

**Errors are typed, not stringly.** `lib/errors/app-error.ts` defines a small closed set of error codes with HTTP-equivalent statuses and separate `message` (developer-facing) vs. `userMessage` (safe to render) fields. `app/error.tsx` and `app/global-error.tsx` cover the two levels of failure Next.js can hand back — a segment throwing, and the root layout itself throwing.

**Theming is CSS variables, not a theme object.** Colors live in `globals.css` as HSL triples, referenced by Tailwind config under semantic names (`background`, `primary`, `destructive`, …). Components never write `dark:` variants or import a theme file — they use `bg-background`, and `next-themes` flips the `dark` class on `<html>`. This is what makes shadcn/ui components (and any new ones you generate via the CLI) drop in without modification.

**One config file per concern.** `config/site.ts` and `config/routes.ts` exist so renaming the product or adding a protected section is a one-line change in one file, not a grep-and-replace across the app.

## Code quality

- **TypeScript strict mode** with `noUncheckedIndexedAccess`, `noUnusedLocals/Parameters` — see `tsconfig.json`.
- **ESLint** (flat config) extends `next/core-web-vitals`, `next/typescript`, and Tailwind class-order/validity linting.
- **Prettier** with `prettier-plugin-tailwindcss` for deterministic class ordering.
- **Husky + lint-staged** run lint/format on staged files before every commit.
- **Vitest + Testing Library** for unit tests; see `src/lib/errors/app-error.test.ts` for the convention.

```bash
npm run lint        # ESLint
npm run typecheck    # tsc --noEmit
npm run format        # Prettier write
npm test               # Vitest
```

## Environment variables

See `.env.example` — every variable is documented inline, including where to find it in the Supabase dashboard and which ones are server-only. `src/lib/env.ts` validates all of them with Zod at startup, so a missing/misconfigured variable fails fast and loudly instead of surfacing as a confusing runtime error three requests later.

## Deployment

Deploys to Vercel. Set the variables from `.env.example` in Project Settings → Environment Variables (scoped per environment). The `X-Frame-Options`, `X-Content-Type-Options`, and `Referrer-Policy` headers are set in `next.config.ts` for every route.

`GET /api/health` is a lightweight liveness probe (checks Next.js **and** Supabase reachability) suitable for uptime monitoring.

## Authentication

Fully implemented against Supabase Auth — no mocked flows:

| Flow | Route | Notes |
|---|---|---|
| Password sign-in | `/sign-in` | Password tab, with "Forgot password?" inline |
| Magic link sign-in | `/sign-in` | Second tab on the same screen |
| Google / GitHub OAuth | `/sign-in`, `/sign-up` | Redirects through `/auth/callback` |
| Sign-up | `/sign-up` | Routes to `/verify-email` on success |
| Email verification | `/verify-email` | Resend button; landing point after sign-up |
| Forgot password | `/forgot-password` | Always shows a generic success state (no account enumeration) |
| Reset password | `/reset-password` | Guards on an active recovery session; shows an expired-link state otherwise |
| Sign out | Header account menu, home page | `<form action={signOut}>` |

**Where the logic lives:**
- `lib/auth/schemas.ts` — Zod schemas shared between client-side validation (React Hook Form) and the server action's own re-validation.
- `lib/auth/actions.ts` — every mutating auth flow as a Server Action. Password/magic-link/reset flows run server-side so session cookies are set directly; OAuth is the one exception (`components/auth/oauth-buttons.tsx`) since redirecting to a provider's consent screen has to happen in the browser.
- `lib/auth/error-messages.ts` — maps Supabase's raw error strings to copy we control, so a provider wording change can't leak into the UI unreviewed.
- `components/auth/` — one form component per flow, each self-contained (validation, submit state, error/success rendering) and composed into the `(auth)` route pages.

**Security notes:** forgot-password and magic-link requests always return the same success response regardless of whether the email has an account (`requestPasswordReset`, `requestMagicLink`) — this prevents using the auth forms to enumerate registered emails. Passwords require 8+ characters with mixed case and a number, enforced identically on client and server.

**Enabling Google/GitHub sign-in:** OAuth client IDs/secrets are configured in the Supabase Dashboard (Authentication → Providers), not in this app's environment variables — the app only needs to know the provider name (`google` / `github`) it's requesting. Add the app's `/auth/callback` URL to each provider's allowed redirect URIs and to Supabase's redirect allow-list.

## What's intentionally not here yet

Dashboard, learning flows, practice flows, wallet, paid tasks, and profile are product features layered on top of this foundation in later work — none of them are represented here, including in navigation or route protection lists, so their design isn't presupposed by this scaffold.
