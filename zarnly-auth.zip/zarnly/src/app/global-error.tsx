"use client";

/**
 * Last-resort error boundary.
 *
 * Only triggers when the ROOT layout itself throws — in that case
 * `app/error.tsx` can't render (it depends on the root layout), so this
 * file must render its own <html>/<body> and avoid importing anything
 * that could itself fail (no theme provider, no design system state).
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "system-ui, sans-serif" }}>
        <div
          style={{
            display: "flex",
            minHeight: "100dvh",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: "1rem",
            padding: "1rem",
            textAlign: "center",
          }}
        >
          <h1 style={{ fontSize: "1.25rem", fontWeight: 600 }}>Zarnly is unavailable</h1>
          <p style={{ fontSize: "0.875rem", color: "#666", maxWidth: 360 }}>
            A critical error occurred. Please refresh the page. If this keeps happening,
            contact support.
          </p>
          {error.digest && (
            <p style={{ fontSize: "0.75rem", color: "#999" }}>Reference: {error.digest}</p>
          )}
          <button
            onClick={reset}
            style={{
              padding: "0.5rem 1rem",
              borderRadius: "0.375rem",
              border: "1px solid #d4d4d4",
              background: "#111",
              color: "#fff",
              fontSize: "0.875rem",
              cursor: "pointer",
            }}
          >
            Try again
          </button>
        </div>
      </body>
    </html>
  );
}
