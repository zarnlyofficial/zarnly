import { NextResponse, type NextRequest } from "next/server";

import { createClient } from "@/lib/supabase/server";
import { publicRoutes } from "@/config/routes";

/**
 * Auth callback endpoint.
 *
 * Supabase Auth redirects here after email confirmation, magic link
 * verification, or OAuth provider sign-in, with a `code` query param.
 * We exchange that code for a session and set the resulting cookies,
 * then redirect into the app.
 *
 * This route is intentionally provider-agnostic — it will work
 * unchanged once magic link, password, or OAuth sign-in UI is added.
 */
export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const redirectTo = searchParams.get("redirectTo") ?? publicRoutes.home;

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      return NextResponse.redirect(`${origin}${redirectTo}`);
    }
  }

  const errorUrl = new URL("/sign-in", origin);
  errorUrl.searchParams.set("error", "auth_callback_failed");
  return NextResponse.redirect(errorUrl);
}
