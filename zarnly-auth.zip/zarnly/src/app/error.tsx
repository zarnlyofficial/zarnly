"use client";

/**
 * Segment-level error boundary.
 *
 * Next.js renders this automatically whenever a Server or Client
 * Component throws during rendering within this segment. It receives
 * the thrown error and a `reset()` function that re-renders the segment.
 *
 * Error boundaries are `"use client"` by requirement of the framework —
 * this does not mean error *handling* is client-only; server errors are
 * caught here too, just rendered on the client.
 */

import { useEffect } from "react";
import { AlertTriangle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { toAppError } from "@/lib/errors/app-error";

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  const appError = toAppError(error);

  useEffect(() => {
    // eslint-disable-next-line no-console -- client-side error boundaries
    // can't reach the server logger; this is the sanctioned client sink.
    console.error("[Zarnly] Unhandled error:", error);
  }, [error]);

  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-4 text-center">
      <div className="flex size-12 items-center justify-center rounded-full bg-destructive/10">
        <AlertTriangle className="size-6 text-destructive" aria-hidden="true" />
      </div>
      <div className="space-y-1">
        <h2 className="text-lg font-semibold text-foreground">Something went wrong</h2>
        <p className="max-w-sm text-sm text-muted-foreground">{appError.userMessage}</p>
        {error.digest && (
          <p className="text-xs text-muted-foreground/70">Reference: {error.digest}</p>
        )}
      </div>
      <Button onClick={reset}>Try again</Button>
    </div>
  );
}
