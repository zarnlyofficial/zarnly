import type { Metadata } from "next";
import Link from "next/link";

import { AuthCard } from "@/components/auth/auth-card";
import { ResetPasswordForm } from "@/components/auth/reset-password-form";
import { authPaths } from "@/config/routes";
import { getCurrentUser } from "@/lib/auth/session";

export const metadata: Metadata = { title: "Set a new password" };

/**
 * Reached after clicking a password-reset email link, once
 * `app/auth/callback/route.ts` has exchanged the recovery code for a
 * session. If there's no session here, the link was already used,
 * expired, or was tampered with — show a clear dead end instead of a
 * form that will just fail on submit.
 *
 * This route intentionally is NOT in `authRoutes` (see config/routes.ts),
 * so middleware won't redirect an authenticated recovery session away
 * before the user can set a new password.
 */
export default async function ResetPasswordPage() {
  const user = await getCurrentUser();

  if (!user) {
    return (
      <AuthCard
        title="Link expired"
        description="This password reset link is invalid or has already been used"
        footer={
          <Link href={authPaths.forgotPassword} className="font-medium text-primary hover:underline">
            Request a new link
          </Link>
        }
      >
        <p className="text-center text-sm text-muted-foreground">
          Reset links are single-use and expire after a period of time for your security.
        </p>
      </AuthCard>
    );
  }

  return <ResetPasswordForm />;
}
