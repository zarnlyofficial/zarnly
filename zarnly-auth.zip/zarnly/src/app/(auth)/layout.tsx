import type { ReactNode } from "react";

/**
 * Layout for unauthenticated flows (sign in, sign up, password reset).
 *
 * Deliberately chrome-free — no header/footer — so auth pages can render
 * a focused, centered card without fighting the app shell. Actual
 * sign-in/sign-up pages are a later feature slice; this group exists now
 * so `middleware.ts` has a stable set of auth routes to redirect to/from.
 */
export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-background px-4 py-12">
      <div className="w-full max-w-sm">{children}</div>
    </div>
  );
}
