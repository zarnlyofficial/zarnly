import type { Metadata } from "next";
import Link from "next/link";
import { MailCheck } from "lucide-react";

import { AuthCard } from "@/components/auth/auth-card";
import { ResendVerificationButton } from "@/components/auth/resend-verification-button";
import { authPaths } from "@/config/routes";

export const metadata: Metadata = { title: "Verify your email" };

export default async function VerifyEmailPage({
  searchParams,
}: {
  searchParams: Promise<{ email?: string }>;
}) {
  const { email } = await searchParams;

  return (
    <AuthCard
      title="Check your inbox"
      description={email ? `We sent a verification link to ${email}` : "We sent you a verification link"}
      footer={
        <Link href={authPaths.signIn} className="font-medium text-primary hover:underline">
          Back to sign in
        </Link>
      }
    >
      <div className="flex justify-center">
        <div className="flex size-12 items-center justify-center rounded-full bg-primary/10">
          <MailCheck className="size-6 text-primary" aria-hidden="true" />
        </div>
      </div>

      <p className="text-center text-sm text-muted-foreground">
        Click the link in the email to verify your address. Didn&apos;t get it? Check spam, or request
        another below.
      </p>

      {email && <ResendVerificationButton email={email} />}
    </AuthCard>
  );
}
