import type { Metadata } from "next";
import { Suspense } from "react";

import { LoginForm } from "@/components/auth/login-form";
import { LoadingSpinner } from "@/components/shared/loading-spinner";

export const metadata: Metadata = { title: "Sign in" };

/**
 * `LoginForm` reads `redirectTo`/`error` via `useSearchParams()`, which
 * requires a Suspense boundary — without it Next.js would de-opt this
 * entire route to fully dynamic rendering at build time.
 */
export default function SignInPage() {
  return (
    <Suspense fallback={<LoadingSpinner size="lg" />}>
      <LoginForm />
    </Suspense>
  );
}
