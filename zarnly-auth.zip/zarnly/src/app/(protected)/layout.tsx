import type { ReactNode } from "react";

import { requireUser } from "@/lib/auth/session";
import { AppHeader } from "@/components/layout/app-header";

/**
 * Layout for authenticated app sections.
 *
 * `middleware.ts` already blocks unauthenticated requests from reaching
 * routes under this group (once `protectedRoutePrefixes` lists them).
 * Calling `requireUser()` here too is deliberate defense-in-depth: it
 * guarantees any Server Component in this tree can call `requireUser()`
 * and get a non-null user, even if a route prefix is ever misconfigured.
 *
 * No business sections are mounted here yet — this is the shell that
 * future authenticated features (dashboard, settings, etc.) will render
 * inside of.
 */
export default async function ProtectedLayout({ children }: { children: ReactNode }) {
  await requireUser();

  return (
    <div className="flex min-h-dvh flex-col">
      <AppHeader />
      <main className="flex-1">{children}</main>
    </div>
  );
}
