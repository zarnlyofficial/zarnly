import { NextResponse } from "next/server";

import { createClient } from "@/lib/supabase/server";
import { logError } from "@/lib/errors/logger";

/**
 * Liveness/readiness probe for uptime monitors and deployment checks.
 * Confirms the app can reach Supabase, not just that Next.js is up.
 * Intentionally unauthenticated and lightweight — do not add business
 * logic here.
 */
export async function GET() {
  try {
    const supabase = await createClient();
    const { error } = await supabase.auth.getSession();

    if (error) {
      throw error;
    }

    return NextResponse.json({ status: "ok", timestamp: new Date().toISOString() });
  } catch (error) {
    logError(error, { scope: "health-check" });
    return NextResponse.json(
      { status: "error", timestamp: new Date().toISOString() },
      { status: 503 },
    );
  }
}
