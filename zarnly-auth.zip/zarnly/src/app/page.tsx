import Link from "next/link";

import { Container } from "@/components/layout/container";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { authPaths } from "@/config/routes";
import { siteConfig } from "@/config/site";
import { signOut } from "@/lib/auth/actions";
import { getCurrentUser } from "@/lib/auth/session";

/**
 * Root route.
 *
 * Not a marketing page or a dashboard — neither exists yet. It's a
 * foundation status view that also doubles as a real, working entry
 * point into the auth flows below, and gives future feature work a real
 * page to replace.
 */
export default async function HomePage() {
  const user = await getCurrentUser();

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b border-border">
        <Container className="flex h-14 items-center justify-between">
          <span className="text-sm font-semibold tracking-tight">{siteConfig.name}</span>
          <ThemeToggle />
        </Container>
      </header>

      <main className="flex-1">
        <Container className="flex max-w-2xl flex-col gap-6 py-16">
          <div className="space-y-1.5">
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">
              Foundation ready
            </h1>
            <p className="text-sm text-muted-foreground">
              Auth, theming, and data wiring are live. Product features build on top of this.
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Session</CardTitle>
              <CardDescription>Resolved server-side via Supabase Auth.</CardDescription>
            </CardHeader>
            <CardContent>
              {user ? (
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <p className="text-sm text-foreground">
                    Signed in as <span className="font-medium">{user.email}</span>
                  </p>
                  <form action={signOut}>
                    <Button type="submit" variant="outline" size="sm">
                      Sign out
                    </Button>
                  </form>
                </div>
              ) : (
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <p className="text-sm text-muted-foreground">No active session.</p>
                  <div className="flex gap-2">
                    <Button asChild variant="outline" size="sm">
                      <Link href={authPaths.signUp}>Sign up</Link>
                    </Button>
                    <Button asChild size="sm">
                      <Link href={authPaths.signIn}>Sign in</Link>
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </Container>
      </main>
    </div>
  );
}
