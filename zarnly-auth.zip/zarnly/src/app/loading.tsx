import { LoadingSpinner } from "@/components/shared/loading-spinner";

/**
 * Automatically rendered by Next.js while this route segment (and its
 * data dependencies) are loading, via React Suspense. Individual routes
 * can override this by adding their own `loading.tsx` — this one is the
 * fallback for segments that don't.
 */
export default function Loading() {
  return (
    <div className="flex min-h-dvh items-center justify-center">
      <LoadingSpinner size="lg" />
    </div>
  );
}
