import { NextResponse, type NextRequest } from "next/server";

import { updateSession } from "@/lib/supabase/middleware";
import { authRoutes, protectedRoutePrefixes, publicRoutes } from "@/config/routes";

/**
 * Route protection.
 *
 * Runs on every request matched by `config.matcher` below. Responsibilities:
 *
 *  1. Refresh the Supabase session (delegated to `updateSession`) so
 *     Server Components downstream never see a stale/expired token.
 *  2. Redirect unauthenticated users away from protected routes.
 *  3. Redirect authenticated users away from auth routes (sign in / up)
 *     back into the app.
 *
 * Anything not explicitly listed in `protectedRoutePrefixes` is treated
 * as public — protection is opt-in per route group, not opt-out, so
 * new public routes never accidentally require auth.
 */
export async function middleware(request: NextRequest) {
  const { response, user } = await updateSession(request);
  const { pathname } = request.nextUrl;

  const isProtectedRoute = protectedRoutePrefixes.some((prefix) =>
    pathname.startsWith(prefix),
  );
  const isAuthRoute = authRoutes.some((route) => pathname.startsWith(route));

  if (isProtectedRoute && !user) {
    const redirectUrl = new URL(authRoutes[0], request.url);
    redirectUrl.searchParams.set("redirectTo", pathname);
    return NextResponse.redirect(redirectUrl);
  }

  if (isAuthRoute && user) {
    return NextResponse.redirect(new URL(publicRoutes.home, request.url));
  }

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static, _next/image (Next.js internals)
     * - favicon.ico, and common static asset extensions
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
