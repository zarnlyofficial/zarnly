import { cn } from "@/lib/utils";

/**
 * Base skeleton primitive. Compose into feature-specific skeletons
 * (e.g. a `TaskListSkeleton`) by stacking sized/shaped instances rather
 * than building bespoke shimmer markup per feature.
 */
export function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("animate-pulse rounded-md bg-muted", className)}
      {...props}
    />
  );
}
