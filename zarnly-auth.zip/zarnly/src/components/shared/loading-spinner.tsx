import { Loader2 } from "lucide-react";

import { cn } from "@/lib/utils";

const SIZE_CLASSES = {
  sm: "size-4",
  md: "size-6",
  lg: "size-8",
} as const;

interface LoadingSpinnerProps {
  size?: keyof typeof SIZE_CLASSES;
  className?: string;
  label?: string;
}

export function LoadingSpinner({ size = "md", className, label = "Loading" }: LoadingSpinnerProps) {
  return (
    <div role="status" className="inline-flex items-center justify-center">
      <Loader2 className={cn("animate-spin text-muted-foreground", SIZE_CLASSES[size], className)} />
      <span className="sr-only">{label}</span>
    </div>
  );
}
