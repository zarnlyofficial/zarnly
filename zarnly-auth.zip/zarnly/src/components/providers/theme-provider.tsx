"use client";

import * as React from "react";
import { ThemeProvider as NextThemesProvider } from "next-themes";
import type { ThemeProviderProps } from "next-themes";

/**
 * Thin wrapper around next-themes.
 *
 * Handles light/dark/system theme switching by toggling a `class` on
 * `<html>`, which the CSS variables in globals.css key off of. Kept as
 * its own file (rather than inlined in AppProviders) so it can be
 * unit-tested or swapped independently.
 */
export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  return (
    <NextThemesProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange {...props}>
      {children}
    </NextThemesProvider>
  );
}
