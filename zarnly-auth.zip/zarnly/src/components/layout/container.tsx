import type { ReactNode } from "react";

import { cn } from "@/lib/utils";

/**
 * Consistent max-width + horizontal padding wrapper. Every page-level
 * layout should compose content inside this rather than redefining
 * padding/max-width ad hoc, so the content column stays visually
 * consistent app-wide and responsive breakpoints are defined once.
 */
export function Container({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8", className)}>{children}</div>;
}
