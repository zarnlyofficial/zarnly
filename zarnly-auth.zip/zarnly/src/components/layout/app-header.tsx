import Link from "next/link";

import { Container } from "@/components/layout/container";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { UserNav } from "@/components/layout/user-nav";
import { publicRoutes } from "@/config/routes";
import { siteConfig } from "@/config/site";
import { requireUser } from "@/lib/auth/session";

/**
 * Header for the authenticated app shell (`(protected)` route group).
 * `requireUser()` is cheap here — it's wrapped in React `cache()`, so
 * this reuses the same lookup the parent layout already made rather
 * than issuing a second request. Nav items are intentionally minimal
 * since no authenticated features exist in the foundation yet.
 */
export async function AppHeader() {
  const user = await requireUser();

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
      <Container className="flex h-14 items-center justify-between">
        <Link href={publicRoutes.home} className="text-sm font-semibold tracking-tight text-foreground">
          {siteConfig.name}
        </Link>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <UserNav user={user} />
        </div>
      </Container>
    </header>
  );
}
