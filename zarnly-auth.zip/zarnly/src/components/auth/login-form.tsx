"use client";

import * as React from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";

import { AuthCard } from "@/components/auth/auth-card";
import { AuthDivider } from "@/components/auth/auth-divider";
import { OAuthButtons } from "@/components/auth/oauth-buttons";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/ui/password-input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { authPaths, publicRoutes } from "@/config/routes";
import { requestMagicLink, signInWithPassword } from "@/lib/auth/actions";
import { loginSchema, magicLinkSchema, type LoginInput, type MagicLinkInput } from "@/lib/auth/schemas";

export function LoginForm() {
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirectTo") || publicRoutes.home;
  const callbackFailed = searchParams.get("error") !== null;

  return (
    <AuthCard
      title="Welcome back"
      description="Sign in to your Zarnly account"
      footer={
        <>
          Don&apos;t have an account?{" "}
          <Link href={authPaths.signUp} className="font-medium text-primary hover:underline">
            Sign up
          </Link>
        </>
      }
    >
      {callbackFailed && (
        <Alert variant="destructive">
          <AlertDescription>That link is invalid or has expired. Please try again.</AlertDescription>
        </Alert>
      )}

      <OAuthButtons />
      <AuthDivider label="Or continue with" />

      <Tabs defaultValue="password">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="password">Password</TabsTrigger>
          <TabsTrigger value="magic-link">Magic link</TabsTrigger>
        </TabsList>
        <TabsContent value="password">
          <PasswordLoginForm redirectTo={redirectTo} />
        </TabsContent>
        <TabsContent value="magic-link">
          <MagicLinkLoginForm />
        </TabsContent>
      </Tabs>
    </AuthCard>
  );
}

function PasswordLoginForm({ redirectTo }: { redirectTo: string }) {
  const [formError, setFormError] = React.useState<string | null>(null);
  const [unconfirmedEmail, setUnconfirmedEmail] = React.useState<string | null>(null);

  const form = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  async function onSubmit(values: LoginInput) {
    setFormError(null);
    setUnconfirmedEmail(null);

    // On success this redirects and never returns — reaching the code
    // below means sign-in failed.
    const result = await signInWithPassword(values, redirectTo);
    setFormError(result.error);
    if (result.code === "email_not_confirmed") {
      setUnconfirmedEmail(values.email);
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" noValidate>
        {formError && (
          <Alert variant="destructive">
            <AlertDescription>
              {formError}
              {unconfirmedEmail && (
                <>
                  {" "}
                  <Link
                    href={`${authPaths.verifyEmail}?email=${encodeURIComponent(unconfirmedEmail)}`}
                    className="font-medium underline underline-offset-2"
                  >
                    Resend verification email
                  </Link>
                </>
              )}
            </AlertDescription>
          </Alert>
        )}

        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" autoComplete="email" placeholder="you@example.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <div className="flex items-center justify-between">
                <FormLabel>Password</FormLabel>
                <Link href={authPaths.forgotPassword} className="text-sm text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
              <FormControl>
                <PasswordInput autoComplete="current-password" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={form.formState.isSubmitting}>
          {form.formState.isSubmitting && <Loader2 className="animate-spin" />}
          Sign in
        </Button>
      </form>
    </Form>
  );
}

function MagicLinkLoginForm() {
  const [formError, setFormError] = React.useState<string | null>(null);
  const [sentTo, setSentTo] = React.useState<string | null>(null);

  const form = useForm<MagicLinkInput>({
    resolver: zodResolver(magicLinkSchema),
    defaultValues: { email: "" },
  });

  async function onSubmit(values: MagicLinkInput) {
    setFormError(null);
    const result = await requestMagicLink(values);
    if (result.success) {
      setSentTo(values.email);
    } else {
      setFormError(result.error);
    }
  }

  if (sentTo) {
    return (
      <Alert variant="success">
        <AlertDescription>
          We sent a sign-in link to <span className="font-medium">{sentTo}</span>. Check your inbox.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" noValidate>
        {formError && (
          <Alert variant="destructive">
            <AlertDescription>{formError}</AlertDescription>
          </Alert>
        )}

        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" autoComplete="email" placeholder="you@example.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={form.formState.isSubmitting}>
          {form.formState.isSubmitting && <Loader2 className="animate-spin" />}
          Send magic link
        </Button>
      </form>
    </Form>
  );
}
