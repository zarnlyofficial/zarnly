"use client";

/**
 * OAuth sign-in buttons.
 *
 * Unlike the password/magic-link flows, this deliberately calls the
 * *browser* Supabase client, not a server action: `signInWithOAuth`
 * needs to navigate the actual browser tab to the provider's consent
 * screen, which only client-side code can trigger. The provider then
 * redirects back to `/auth/callback`, which exchanges the resulting
 * code for a session using the server client — same landing point as
 * every other auth flow in this app.
 */

import * as React from "react";
import { Github, Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { GoogleIcon } from "@/components/icons/google-icon";
import { useToast } from "@/hooks/use-toast";
import { clientEnv } from "@/lib/env";
import { createClient } from "@/lib/supabase/client";

type Provider = "google" | "github";

const PROVIDER_LABEL: Record<Provider, string> = {
  google: "Google",
  github: "GitHub",
};

export function OAuthButtons() {
  const [loadingProvider, setLoadingProvider] = React.useState<Provider | null>(null);
  const { toast } = useToast();

  async function handleOAuth(provider: Provider) {
    setLoadingProvider(provider);
    const supabase = createClient();

    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: `${clientEnv.NEXT_PUBLIC_APP_URL}/auth/callback`,
      },
    });

    // On success the browser is already navigating away to the
    // provider's consent screen — there's no further state to update.
    if (error) {
      setLoadingProvider(null);
      toast({
        variant: "destructive",
        title: "Couldn't connect",
        description: `We weren't able to start sign-in with ${PROVIDER_LABEL[provider]}. Please try again.`,
      });
    }
  }

  return (
    <div className="grid grid-cols-2 gap-3">
      <Button
        type="button"
        variant="outline"
        onClick={() => handleOAuth("google")}
        disabled={loadingProvider !== null}
        aria-label="Continue with Google"
      >
        {loadingProvider === "google" ? (
          <Loader2 className="animate-spin" />
        ) : (
          <GoogleIcon className="size-4" />
        )}
        Google
      </Button>
      <Button
        type="button"
        variant="outline"
        onClick={() => handleOAuth("github")}
        disabled={loadingProvider !== null}
        aria-label="Continue with GitHub"
      >
        {loadingProvider === "github" ? <Loader2 className="animate-spin" /> : <Github className="size-4" />}
        GitHub
      </Button>
    </div>
  );
}
