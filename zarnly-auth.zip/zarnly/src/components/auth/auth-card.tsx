import type { ReactNode } from "react";
import Link from "next/link";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { publicRoutes } from "@/config/routes";
import { siteConfig } from "@/config/site";

/**
 * Consistent chrome for every screen in the `(auth)` route group: brand
 * mark, a titled card, and an optional footer line (e.g. "Don't have an
 * account? Sign up"). Individual forms only render their fields —
 * this owns the surrounding layout so every auth screen looks and
 * behaves the same way.
 */
export function AuthCard({
  title,
  description,
  children,
  footer,
}: {
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div className="space-y-6">
      <Link
        href={publicRoutes.home}
        className="flex items-center justify-center text-sm font-semibold tracking-tight text-foreground"
      >
        {siteConfig.name}
      </Link>

      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-xl">{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </CardHeader>
        <CardContent className="space-y-6">{children}</CardContent>
      </Card>

      {footer && <p className="text-center text-sm text-muted-foreground">{footer}</p>}
    </div>
  );
}
