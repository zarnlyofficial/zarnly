"use client";

import * as React from "react";
import { Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { resendVerificationEmail } from "@/lib/auth/actions";

export function ResendVerificationButton({ email }: { email: string }) {
  const [isPending, setIsPending] = React.useState(false);
  const { toast } = useToast();

  async function handleClick() {
    setIsPending(true);
    const result = await resendVerificationEmail(email);
    setIsPending(false);

    toast(
      result.success
        ? { title: "Email sent", description: `We resent the verification link to ${email}.` }
        : { variant: "destructive", title: "Couldn't resend", description: result.error },
    );
  }

  return (
    <Button variant="outline" className="w-full" onClick={handleClick} disabled={isPending}>
      {isPending && <Loader2 className="animate-spin" />}
      Resend verification email
    </Button>
  );
}
