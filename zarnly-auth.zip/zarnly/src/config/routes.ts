/**
 * Single source of truth for route paths.
 *
 * Route protection in `middleware.ts`, redirects, and nav components all
 * reference this file instead of hardcoding path strings, so adding a new
 * protected section is a one-line change made in exactly one place.
 */

export const publicRoutes = {
  home: "/",
} as const;

/**
 * Every auth-flow path in one place, so forms, redirects, and the
 * middleware all reference the same strings instead of hardcoding them.
 */
export const authPaths = {
  signIn: "/sign-in",
  signUp: "/sign-up",
  forgotPassword: "/forgot-password",
  resetPassword: "/reset-password",
  verifyEmail: "/verify-email",
} as const;

/**
 * Routes that should redirect an already-authenticated user away.
 * Deliberately just sign-in/sign-up: forgot-password and reset-password
 * must stay reachable even for a user with an active (or recovery)
 * session — see reset-password/page.tsx.
 */
export const authRoutes = [authPaths.signIn, authPaths.signUp] as const;

/**
 * Path prefixes that require an authenticated session. Business features
 * will be added under the `(protected)` route group as the product grows;
 * add their prefixes here to bring them under auth protection.
 */
export const protectedRoutePrefixes: string[] = [
  // e.g. "/dashboard", "/settings" — intentionally empty in the
  // foundation; populated as protected features are built.
];
