/**
 * Site-wide constants referenced by metadata, layout chrome, and emails.
 * Centralized so a rename or copy change happens in one place.
 */
export const siteConfig = {
  name: "Zarnly",
  description: "Zarnly.",
  links: {
    twitter: "https://twitter.com/zarnly",
    github: "https://github.com/zarnly",
  },
} as const;
