import "server-only";

/**
 * Resend client singleton.
 *
 * Server-only by construction (`server-only` import + reading
 * `SUPABASE`-style secrets via `getServerEnv()`), so it can never be
 * pulled into a client bundle. Feature code should call `sendEmail`
 * rather than importing the Resend SDK directly, so retry/error handling
 * and the "from" address stay consistent across every email the app sends.
 */

import type { ReactElement } from "react";
import { Resend } from "resend";

import { getServerEnv } from "@/lib/env";
import { AppError } from "@/lib/errors/app-error";
import { logError } from "@/lib/errors/logger";

let resendClient: Resend | undefined;

function getResendClient(): Resend {
  if (!resendClient) {
    resendClient = new Resend(getServerEnv().RESEND_API_KEY);
  }
  return resendClient;
}

interface SendEmailInput {
  to: string | string[];
  subject: string;
  react?: ReactElement;
  html?: string;
  text?: string;
  replyTo?: string;
}

/**
 * Sends a transactional email. Throws `AppError("EXTERNAL_SERVICE_ERROR")`
 * on failure so callers can handle it the same way they handle any other
 * external dependency failing — see `lib/errors/app-error.ts`.
 */
export async function sendEmail(input: SendEmailInput): Promise<{ id: string }> {
  const env = getServerEnv();
  const client = getResendClient();

  const { data, error } = await client.emails.send({
    from: env.RESEND_FROM_EMAIL,
    to: input.to,
    subject: input.subject,
    react: input.react,
    html: input.html,
    text: input.text,
    replyTo: input.replyTo,
  });

  if (error || !data) {
    logError(error, { scope: "resend.sendEmail", subject: input.subject });
    throw new AppError("EXTERNAL_SERVICE_ERROR", error?.message ?? "Failed to send email", {
      userMessage: "We couldn't send that email. Please try again shortly.",
    });
  }

  return { id: data.id };
}
