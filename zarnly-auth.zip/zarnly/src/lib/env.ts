/**
 * Centralized, validated environment access.
 *
 * Every environment variable the app depends on is declared and parsed
 * here exactly once, at import time. Nothing else in the codebase should
 * read `process.env` directly — this keeps env access:
 *
 *  - Type-safe:      consumers get typed values, not `string | undefined`.
 *  - Fail-fast:       a missing/invalid var throws immediately on boot
 *                      (server) or build (client), not deep in a request.
 *  - Discoverable:    one file documents every variable the app needs.
 *  - Safe by default:  server-only secrets are physically unreachable
 *                      from client bundles because this module is only
 *                      imported from server code paths for those keys.
 */

import { z } from "zod";

const clientSchema = z.object({
  NEXT_PUBLIC_APP_URL: z.string().url(),
  NEXT_PUBLIC_APP_ENV: z.enum(["development", "preview", "production"]),
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
  NEXT_PUBLIC_SUPABASE_PROJECT_ID: z.string().min(1),
});

const serverSchema = clientSchema.extend({
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
  RESEND_API_KEY: z.string().min(1),
  RESEND_FROM_EMAIL: z.string().min(1),
  INTERNAL_API_SECRET: z.string().min(16),
});

type ClientEnv = z.infer<typeof clientSchema>;
type ServerEnv = z.infer<typeof serverSchema>;

function formatError(error: z.ZodError): string {
  const issues = error.issues
    .map((issue) => `  - ${issue.path.join(".")}: ${issue.message}`)
    .join("\n");
  return `Invalid environment variables:\n${issues}\n\nCheck .env.example for the full list of required variables.`;
}

function loadClientEnv(): ClientEnv {
  const parsed = clientSchema.safeParse({
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    NEXT_PUBLIC_APP_ENV: process.env.NEXT_PUBLIC_APP_ENV,
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    NEXT_PUBLIC_SUPABASE_PROJECT_ID: process.env.NEXT_PUBLIC_SUPABASE_PROJECT_ID,
  });

  if (!parsed.success) {
    throw new Error(formatError(parsed.error));
  }

  return parsed.data;
}

/**
 * Full env, including secrets. Only ever import `server-only` modules
 * that use this from server components, route handlers, or server actions.
 */
function loadServerEnv(): ServerEnv {
  const parsed = serverSchema.safeParse(process.env);

  if (!parsed.success) {
    throw new Error(formatError(parsed.error));
  }

  return parsed.data;
}

/** Safe to import from client components. */
export const clientEnv: ClientEnv = loadClientEnv();

/**
 * Server-only. Importing this from a client component will throw at
 * build time due to the `server-only` package — see lib/supabase/server.ts
 * and lib/resend/client.ts for the guarded entry points.
 */
export function getServerEnv(): ServerEnv {
  return loadServerEnv();
}

export const isProduction = clientEnv.NEXT_PUBLIC_APP_ENV === "production";
export const isDevelopment = clientEnv.NEXT_PUBLIC_APP_ENV === "development";
