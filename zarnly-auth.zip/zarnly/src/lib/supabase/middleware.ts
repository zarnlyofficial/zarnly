/**
 * Middleware-scoped Supabase session refresh.
 *
 * Next.js middleware runs before every matched request. This helper
 * refreshes the Supabase auth token (if expired) and keeps the request
 * and response cookies in sync, so Server Components downstream always
 * see a valid session without each of them needing to handle refresh.
 *
 * This does NOT do route protection — that lives in `middleware.ts` at
 * the project root, which calls `updateSession` first and then applies
 * routing rules using the returned user.
 */

import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

import { clientEnv } from "@/lib/env";

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient(
    clientEnv.NEXT_PUBLIC_SUPABASE_URL,
    clientEnv.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet: { name: string; value: string; options?: CookieOptions }[]) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) => {
            response.cookies.set(name, value, options);
          });
        },
      },
    },
  );

  // Touching getUser() is what actually triggers a token refresh if the
  // access token is expired. Do not replace with getSession() here —
  // getSession() reads the (possibly stale) local cookie without
  // revalidating against Supabase Auth.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return { response, user };
}
