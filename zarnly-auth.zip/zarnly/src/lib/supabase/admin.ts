import "server-only";

/**
 * Privileged Supabase client using the service role key.
 *
 * This client BYPASSES Row Level Security entirely. Scope of use is
 * intentionally narrow:
 *
 *  - Webhook handlers (e.g. Supabase Auth webhooks, billing webhooks)
 *  - Scheduled/cron jobs
 *  - Admin-only server actions that have already re-verified the caller's
 *    permissions in application code
 *
 * Never import this into anything reachable from a client component, and
 * never use it as a shortcut to avoid writing an RLS policy.
 */

import { createClient as createSupabaseClient } from "@supabase/supabase-js";

import { getServerEnv } from "@/lib/env";
import type { Database } from "@/types/database.types";

let adminClient: ReturnType<typeof createSupabaseClient<Database>> | undefined;

export function createAdminClient() {
  if (adminClient) {
    return adminClient;
  }

  const env = getServerEnv();

  adminClient = createSupabaseClient<Database>(
    env.NEXT_PUBLIC_SUPABASE_URL,
    env.SUPABASE_SERVICE_ROLE_KEY,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    },
  );

  return adminClient;
}
