/**
 * Browser Supabase client.
 *
 * Use inside client components ("use client") only. It reads/writes the
 * auth session via cookies (through @supabase/ssr) so the session stays
 * in sync with server-rendered pages and middleware.
 *
 * Do not use this for privileged operations — it runs with the `anon` key
 * and is bound by Row Level Security policies.
 */

import { createBrowserClient } from "@supabase/ssr";

import { clientEnv } from "@/lib/env";
import type { Database } from "@/types/database.types";

let browserClient: ReturnType<typeof createBrowserClient<Database>> | undefined;

/**
 * Returns a singleton browser Supabase client. Lazily created so it is
 * never instantiated during server-side rendering.
 */
export function createClient() {
  if (browserClient) {
    return browserClient;
  }

  browserClient = createBrowserClient<Database>(
    clientEnv.NEXT_PUBLIC_SUPABASE_URL,
    clientEnv.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  );

  return browserClient;
}
