import "server-only";

/**
 * Server Supabase client.
 *
 * Use inside Server Components, Route Handlers, and Server Actions.
 * Session is read from and (where possible) written back to cookies so
 * refreshed tokens propagate correctly.
 *
 * IMPORTANT: In Server Components, `cookies().set()` is not permitted and
 * will silently no-op (Next.js restriction) — token refresh in that case
 * is completed by `middleware.ts`, which runs on every request. Do not
 * remove the middleware refresh logic even though it looks redundant.
 */

import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";

import { clientEnv } from "@/lib/env";
import type { Database } from "@/types/database.types";

export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient<Database>(
    clientEnv.NEXT_PUBLIC_SUPABASE_URL,
    clientEnv.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet: { name: string; value: string; options?: CookieOptions }[]) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options);
            });
          } catch {
            // Called from a Server Component — session refresh is
            // handled by middleware instead. Safe to ignore.
          }
        },
      },
    },
  );
}
