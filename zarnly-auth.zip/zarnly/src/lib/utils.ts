import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Merges class names, resolving Tailwind class conflicts (e.g. a later
 * `px-4` overriding an earlier `px-2`) in the order they're passed.
 * Standard shadcn/ui convention — used by every component in `ui/`.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
