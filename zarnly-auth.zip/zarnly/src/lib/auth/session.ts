import "server-only";

/**
 * Server-side auth helpers.
 *
 * These wrap Supabase's server client so Server Components, Route
 * Handlers, and Server Actions have one consistent, typed way to ask
 * "who is the current user?" instead of importing the Supabase client
 * directly and repeating boilerplate everywhere.
 */

import { cache } from "react";

import { createClient } from "@/lib/supabase/server";
import type { AuthUser } from "@/types/auth.types";

/**
 * Returns the current authenticated user, or `null`.
 *
 * Wrapped in React's `cache()` so multiple calls within the same request
 * (e.g. from a layout and a page) reuse one network round trip to
 * Supabase Auth instead of firing it repeatedly.
 */
export const getCurrentUser = cache(async (): Promise<AuthUser | null> => {
  const supabase = await createClient();
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    return null;
  }

  return {
    id: user.id,
    email: user.email ?? null,
    emailVerified: user.email_confirmed_at != null,
    createdAt: user.created_at,
  };
});

/**
 * Throws-if-absent variant for use inside routes that are already known
 * to be protected (e.g. layouts under the `(protected)` group), so
 * downstream code can assume a non-null user without re-checking.
 */
export async function requireUser(): Promise<AuthUser> {
  const user = await getCurrentUser();

  if (!user) {
    throw new Error(
      "requireUser() called outside a protected route — no authenticated user found.",
    );
  }

  return user;
}
