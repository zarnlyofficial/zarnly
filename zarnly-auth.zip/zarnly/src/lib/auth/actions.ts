"use server";

/**
 * Auth server actions.
 *
 * Every flow (password login, sign-up, magic link, password reset,
 * verification resend, sign-out) runs here as a Server Action, called
 * directly from client form components (e.g. `await signInWithPassword(values)`
 * inside a React Hook Form `onSubmit`). Running on the server means:
 *
 *  - Zod validation happens again server-side, not just in the browser —
 *    the client-side check is a UX nicety, this is the real gate.
 *  - The Supabase server client can set httpOnly session cookies
 *    directly, which Server Components and middleware can already read.
 *  - Supabase error messages never reach the client unmapped — every
 *    failure goes through `toAuthErrorMessage` first.
 *
 * Success paths that should navigate call `redirect()` directly rather
 * than returning a "success" value — `redirect()` throws internally, and
 * Next.js turns that into a client-side navigation even when the action
 * was invoked programmatically (not via a <form action>).
 */

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";

import { clientEnv } from "@/lib/env";
import { logError } from "@/lib/errors/logger";
import { createClient } from "@/lib/supabase/server";
import { publicRoutes } from "@/config/routes";
import { toAuthErrorMessage } from "@/lib/auth/error-messages";
import {
  forgotPasswordSchema,
  loginSchema,
  magicLinkSchema,
  resetPasswordSchema,
  signupSchema,
  type ForgotPasswordInput,
  type LoginInput,
  type MagicLinkInput,
  type ResetPasswordInput,
  type SignupInput,
} from "@/lib/auth/schemas";

/** Generic result for flows that don't need to carry extra data back. */
export type ActionResult = { success: true } | { success: false; error: string };

/** Failure shape for sign-in — the success path redirects and never returns. */
export type SignInActionResult = {
  success: false;
  error: string;
  code?: "email_not_confirmed";
};

export type SignUpActionResult =
  | { success: true; email: string }
  | { success: false; error: string };

const GENERIC_VALIDATION_ERROR = "Please check the form and try again.";

/**
 * Email + password sign-in. Redirects on success; only ever *returns*
 * on failure (see module doc for why).
 */
export async function signInWithPassword(
  values: LoginInput,
  redirectTo: string = publicRoutes.home,
): Promise<SignInActionResult> {
  const parsed = loginSchema.safeParse(values);
  if (!parsed.success) {
    return { success: false, error: GENERIC_VALIDATION_ERROR };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({
    email: parsed.data.email,
    password: parsed.data.password,
  });

  if (error) {
    logError(error, { scope: "auth.signInWithPassword" });
    return {
      success: false,
      error: toAuthErrorMessage(error),
      code: error.message === "Email not confirmed" ? "email_not_confirmed" : undefined,
    };
  }

  revalidatePath("/", "layout");
  redirect(redirectTo);
}

/**
 * Email + password sign-up. Does not sign the user in directly even if
 * Supabase returns a session (email confirmations could be disabled in
 * some environments) — in that case we still route through the normal
 * post-signup redirect so behavior stays consistent between environments.
 */
export async function signUpWithPassword(values: SignupInput): Promise<SignUpActionResult> {
  const parsed = signupSchema.safeParse(values);
  if (!parsed.success) {
    return { success: false, error: GENERIC_VALIDATION_ERROR };
  }

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      emailRedirectTo: `${clientEnv.NEXT_PUBLIC_APP_URL}/auth/callback`,
    },
  });

  if (error) {
    logError(error, { scope: "auth.signUpWithPassword" });
    return { success: false, error: toAuthErrorMessage(error) };
  }

  // Email confirmations disabled (e.g. some local/dev setups): Supabase
  // returns an active session immediately, so sign-up doubles as sign-in.
  if (data.session) {
    revalidatePath("/", "layout");
    redirect(publicRoutes.home);
  }

  return { success: true, email: parsed.data.email };
}

/**
 * Requests a password reset email. Always reports success to the caller
 * regardless of whether the address has an account — never confirm or
 * deny account existence to an unauthenticated caller.
 */
export async function requestPasswordReset(values: ForgotPasswordInput): Promise<ActionResult> {
  const parsed = forgotPasswordSchema.safeParse(values);
  if (!parsed.success) {
    return { success: false, error: "Enter a valid email address." };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
    redirectTo: `${clientEnv.NEXT_PUBLIC_APP_URL}/auth/callback?redirectTo=/reset-password`,
  });

  if (error) {
    // Logged for observability, but intentionally not surfaced — see
    // the doc comment above.
    logError(error, { scope: "auth.requestPasswordReset" });
  }

  return { success: true };
}

/**
 * Sets a new password. Requires an active session — the user reaches
 * this already signed in via the recovery link's code exchange in
 * `app/auth/callback/route.ts`. See `app/(auth)/reset-password/page.tsx`
 * for the guard that checks for that session before rendering the form.
 */
export async function updatePassword(values: ResetPasswordInput): Promise<ActionResult> {
  const parsed = resetPasswordSchema.safeParse(values);
  if (!parsed.success) {
    return { success: false, error: GENERIC_VALIDATION_ERROR };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });

  if (error) {
    logError(error, { scope: "auth.updatePassword" });
    return { success: false, error: toAuthErrorMessage(error) };
  }

  revalidatePath("/", "layout");
  redirect(publicRoutes.home);
}

/**
 * Sends a passwordless sign-in link. `shouldCreateUser: true` means this
 * doubles as a sign-up path for new emails — intentional, since a magic
 * link is itself proof of email ownership.
 */
export async function requestMagicLink(values: MagicLinkInput): Promise<ActionResult> {
  const parsed = magicLinkSchema.safeParse(values);
  if (!parsed.success) {
    return { success: false, error: "Enter a valid email address." };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithOtp({
    email: parsed.data.email,
    options: {
      emailRedirectTo: `${clientEnv.NEXT_PUBLIC_APP_URL}/auth/callback`,
      shouldCreateUser: true,
    },
  });

  if (error) {
    logError(error, { scope: "auth.requestMagicLink" });
    return { success: false, error: toAuthErrorMessage(error) };
  }

  return { success: true };
}

/** Re-sends the sign-up confirmation email. */
export async function resendVerificationEmail(email: string): Promise<ActionResult> {
  const parsed = forgotPasswordSchema.shape.email.safeParse(email);
  if (!parsed.success) {
    return { success: false, error: "Enter a valid email address." };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.resend({
    type: "signup",
    email: parsed.data,
    options: { emailRedirectTo: `${clientEnv.NEXT_PUBLIC_APP_URL}/auth/callback` },
  });

  if (error) {
    logError(error, { scope: "auth.resendVerificationEmail" });
    return { success: false, error: toAuthErrorMessage(error) };
  }

  return { success: true };
}

export async function signOut(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut();
  revalidatePath("/", "layout");
  redirect(publicRoutes.home);
}
