import type { AuthError } from "@supabase/supabase-js";

/**
 * Supabase Auth returns stable English error `message` strings rather
 * than machine-readable codes for most failures. This maps the ones our
 * flows can actually trigger to copy we control, so wording changes
 * don't require touching every form, and so we never show a raw
 * provider error string to an end user.
 */
const MESSAGES: Record<string, string> = {
  "Invalid login credentials":
    "That email or password isn't right. Double-check and try again.",
  "Email not confirmed":
    "Confirm your email before signing in — check your inbox for the verification link.",
  "User already registered": "An account with this email already exists. Try signing in instead.",
  "Password should be at least 6 characters": "Your password needs to be at least 8 characters.",
  "For security purposes, you can only request this after 60 seconds.":
    "You've requested this recently — please wait a moment before trying again.",
  "Email rate limit exceeded": "Too many attempts. Please wait a few minutes and try again.",
  "Signups not allowed for this instance": "Sign-ups are currently disabled.",
};

export function toAuthErrorMessage(error: Pick<AuthError, "message">): string {
  return MESSAGES[error.message] ?? "Something went wrong. Please try again.";
}
