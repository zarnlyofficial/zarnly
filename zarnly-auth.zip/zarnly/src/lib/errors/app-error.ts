/**
 * Typed application error hierarchy.
 *
 * Route handlers, server actions, and data-access code should throw
 * (or return) these instead of generic `Error`s or raw Supabase/Postgrest
 * errors, so:
 *
 *  - UI code can branch on `error.code` instead of parsing messages.
 *  - Messages shown to users are always intentional copy, never a raw
 *    database or provider error leaking into the UI.
 *  - Every error carries an HTTP-equivalent status for API routes.
 */

export type AppErrorCode =
  | "UNAUTHENTICATED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "VALIDATION_ERROR"
  | "RATE_LIMITED"
  | "EXTERNAL_SERVICE_ERROR"
  | "UNKNOWN_ERROR";

const STATUS_BY_CODE: Record<AppErrorCode, number> = {
  UNAUTHENTICATED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  VALIDATION_ERROR: 422,
  RATE_LIMITED: 429,
  EXTERNAL_SERVICE_ERROR: 502,
  UNKNOWN_ERROR: 500,
};

export class AppError extends Error {
  readonly code: AppErrorCode;
  readonly status: number;
  /** Safe to display to the end user, as opposed to `message` which may be more technical. */
  readonly userMessage: string;
  override readonly cause?: unknown;

  constructor(
    code: AppErrorCode,
    message: string,
    options?: { userMessage?: string; cause?: unknown },
  ) {
    super(message);
    this.name = "AppError";
    this.code = code;
    this.status = STATUS_BY_CODE[code];
    this.userMessage = options?.userMessage ?? "Something went wrong. Please try again.";
    this.cause = options?.cause;
  }
}

export function isAppError(error: unknown): error is AppError {
  return error instanceof AppError;
}

/**
 * Normalizes any thrown value into an AppError, so error boundaries and
 * API routes never have to deal with `unknown` directly.
 */
export function toAppError(error: unknown): AppError {
  if (isAppError(error)) {
    return error;
  }

  if (error instanceof Error) {
    return new AppError("UNKNOWN_ERROR", error.message, { cause: error });
  }

  return new AppError("UNKNOWN_ERROR", "An unknown error occurred.", { cause: error });
}
