import { describe, expect, it } from "vitest";

import { AppError, isAppError, toAppError } from "@/lib/errors/app-error";

describe("AppError", () => {
  it("assigns the correct HTTP status per error code", () => {
    expect(new AppError("NOT_FOUND", "missing").status).toBe(404);
    expect(new AppError("UNAUTHENTICATED", "no session").status).toBe(401);
  });

  it("falls back to a generic user-facing message when none is given", () => {
    const error = new AppError("UNKNOWN_ERROR", "internal detail");
    expect(error.userMessage).toBe("Something went wrong. Please try again.");
  });

  it("isAppError narrows unknown values correctly", () => {
    expect(isAppError(new AppError("FORBIDDEN", "nope"))).toBe(true);
    expect(isAppError(new Error("plain"))).toBe(false);
    expect(isAppError("string")).toBe(false);
  });

  it("toAppError wraps native errors without losing the message", () => {
    const wrapped = toAppError(new Error("boom"));
    expect(wrapped).toBeInstanceOf(AppError);
    expect(wrapped.message).toBe("boom");
    expect(wrapped.code).toBe("UNKNOWN_ERROR");
  });
});
