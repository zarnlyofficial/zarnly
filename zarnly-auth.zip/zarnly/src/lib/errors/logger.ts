import "server-only";

/**
 * Minimal, provider-agnostic logging boundary.
 *
 * Every server-side error should be reported through `logError` rather
 * than a bare `console.error`, so swapping in Sentry/Axiom/Datadog later
 * is a one-file change. Kept deliberately dependency-free for the
 * foundation — wire a real provider here when observability needs grow
 * past console/Vercel log drains.
 */

import { isDevelopment } from "@/lib/env";
import { toAppError } from "@/lib/errors/app-error";

interface LogContext {
  [key: string]: unknown;
}

export function logError(error: unknown, context?: LogContext): void {
  const appError = toAppError(error);

  const payload = {
    level: "error" as const,
    code: appError.code,
    message: appError.message,
    ...(isDevelopment ? { stack: appError.stack } : {}),
    ...context,
  };

  // eslint-disable-next-line no-console -- this is the single sanctioned sink
  console.error(JSON.stringify(payload));
}

export function logWarning(message: string, context?: LogContext): void {
  // eslint-disable-next-line no-console -- this is the single sanctioned sink
  console.warn(JSON.stringify({ level: "warn", message, ...context }));
}
