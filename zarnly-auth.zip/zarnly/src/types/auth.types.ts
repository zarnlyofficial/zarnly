/**
 * Application-level auth types.
 *
 * Deliberately a thin, stable shape derived from Supabase's `User`
 * rather than the raw Supabase type itself — so if we ever change auth
 * providers, only the mapping in `lib/auth/session.ts` changes, not
 * every component that consumes a user.
 */
export interface AuthUser {
  id: string;
  email: string | null;
  emailVerified: boolean;
  createdAt: string;
}

export type AuthState =
  | { status: "loading" }
  | { status: "authenticated"; user: AuthUser }
  | { status: "unauthenticated" };
