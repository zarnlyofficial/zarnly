/**
 * Auto-generated Supabase database types.
 *
 * DO NOT hand-edit this file. Regenerate it once your schema exists:
 *
 *   npm run db:types
 *
 * (wraps `supabase gen types typescript`, see package.json). Until the
 * first migration is applied, this is a minimal valid shape so the rest
 * of the codebase — which imports `Database` for every Supabase client —
 * type-checks.
 */
export interface Database {
  public: {
    Tables: Record<string, never>;
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
    CompositeTypes: Record<string, never>;
  };
}
