import type { AppErrorCode } from "@/lib/errors/app-error";

/**
 * Standard envelope for JSON API routes (`app/api/**\/route.ts`), so
 * every endpoint returns a predictable, typed shape and client code can
 * narrow on `success` instead of guessing a route's response shape.
 */
export type ApiResponse<T> = ApiSuccess<T> | ApiFailure;

export interface ApiSuccess<T> {
  success: true;
  data: T;
}

export interface ApiFailure {
  success: false;
  error: {
    code: AppErrorCode;
    message: string;
  };
}

export function apiSuccess<T>(data: T): ApiSuccess<T> {
  return { success: true, data };
}

export function apiFailure(code: AppErrorCode, message: string): ApiFailure {
  return { success: false, error: { code, message } };
}
