"use client";

/**
 * Client-side auth state hook.
 *
 * For Server Components, prefer `getCurrentUser()` from
 * `lib/auth/session.ts` instead — this hook exists for client components
 * that need to react to sign-in/sign-out happening in the same tab
 * (e.g. a header avatar menu) without a full page reload.
 */

import { useEffect, useState } from "react";

import { createClient } from "@/lib/supabase/client";
import type { AuthState } from "@/types/auth.types";

export function useAuth(): AuthState {
  const [state, setState] = useState<AuthState>({ status: "loading" });

  useEffect(() => {
    const supabase = createClient();

    supabase.auth.getUser().then(({ data: { user } }) => {
      setState(
        user
          ? {
              status: "authenticated",
              user: {
                id: user.id,
                email: user.email ?? null,
                emailVerified: user.email_confirmed_at != null,
                createdAt: user.created_at,
              },
            }
          : { status: "unauthenticated" },
      );
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setState(
        session?.user
          ? {
              status: "authenticated",
              user: {
                id: session.user.id,
                email: session.user.email ?? null,
                emailVerified: session.user.email_confirmed_at != null,
                createdAt: session.user.created_at,
              },
            }
          : { status: "unauthenticated" },
      );
    });

    return () => subscription.unsubscribe();
  }, []);

  return state;
}
