"use client";

import { useEffect, useState } from "react";

/**
 * Subscribes to a CSS media query. Prefer Tailwind responsive classes
 * for layout — reach for this only when a component needs to branch its
 * *logic* (not just styling) on viewport size, e.g. rendering a sheet on
 * mobile vs. a popover on desktop.
 */
export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    const mediaQueryList = window.matchMedia(query);
    setMatches(mediaQueryList.matches);

    const listener = (event: MediaQueryListEvent) => setMatches(event.matches);
    mediaQueryList.addEventListener("change", listener);
    return () => mediaQueryList.removeEventListener("change", listener);
  }, [query]);

  return matches;
}

/** Convenience wrapper matching Tailwind's default `md` breakpoint. */
export function useIsMobile(): boolean {
  return !useMediaQuery("(min-width: 768px)");
}
