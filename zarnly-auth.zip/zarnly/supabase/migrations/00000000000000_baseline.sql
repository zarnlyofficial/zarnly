-- ─────────────────────────────────────────────────────────────────────────
-- Zarnly — baseline migration
--
-- This is a foundation migration, not a feature migration: it establishes
-- project-wide conventions rather than any product table. Real tables
-- (tasks, wallets, etc.) get their own numbered migration files following
-- the pattern demonstrated here.
-- ─────────────────────────────────────────────────────────────────────────

-- Every table this project creates MUST enable Row Level Security and
-- define explicit policies — there is no reliance on the service role
-- key for normal app reads/writes. Convention, not enforced by SQL:
--
--   alter table public.<table> enable row level security;
--
--   create policy "<table>_select_own"
--     on public.<table> for select
--     using (auth.uid() = user_id);
--
-- A reusable `updated_at` trigger, since most tables will want one:

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

comment on function public.set_updated_at() is
  'Sets updated_at to now() on any row update. Attach via:
   create trigger set_updated_at before update on public.<table>
   for each row execute function public.set_updated_at();';
